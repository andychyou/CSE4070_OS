#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include <string.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "threads/synch.h"

static void syscall_handler (struct intr_frame *);

void syscall_init (void){
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void syscall_handler (struct intr_frame *f){  
	void *esp_addr = (f->esp);
	pid_t temp_process; 
	
	switch((*(uint32_t *)esp_addr)){
		case SYS_HALT:
			shutdown_power_off();
			break;

		case SYS_EXIT:
			if(!is_user_vaddr(esp_addr+4)) sys_exit(-1);
			sys_exit(*(uint32_t*)(esp_addr+4));
			break;

		case SYS_EXEC :
			if(!is_user_vaddr(esp_addr+4)) sys_exit(-1);
			f->eax = process_execute((char*)*(uint32_t*)(esp_addr+4));
			break;

		case SYS_WAIT :
			if(!is_user_vaddr(esp_addr+4)) sys_exit(-1);
			temp_process = (int)*(uint32_t*)(esp_addr+4);
			f->eax = process_wait(temp_process);
			break;

		case SYS_READ:
			if(!is_user_vaddr((void*)*(uint32_t*)(esp_addr+8))) sys_exit(-1);
			f->eax = sys_read (esp_addr, (int)*(uint32_t*)(esp_addr+4),(void*)*(uint32_t*)(esp_addr+8),
					(int)*(uint32_t*)(esp_addr+12));
			// hex_dump(esp_addr, esp_addr, 100, 1);
			break;

		case SYS_WRITE:
			if(!is_user_vaddr((const void*)*(uint32_t*)(esp_addr+8))) sys_exit(-1);
			f->eax = sys_write((int)*(uint32_t*)(esp_addr+4), (void*)*(uint32_t*)(esp_addr+8),
					(unsigned)*(uint32_t*)(esp_addr+12));
			break;

			
		case SYS_FIB:
			f->eax=sys_fibonacci((int)*(uint32_t*)(esp_addr+4));
			break;

		case SYS_MAX4:
			f->eax=sys_max_of_four_int((int)*(uint32_t*)(esp_addr+4),
				   (int)*(uint32_t*)(esp_addr+8),
				   (int)*(uint32_t*)(esp_addr+12),
				   (int)*(uint32_t*)(esp_addr+16));
			break;

		//Proj 2
		case SYS_CREATE:
			if(!is_user_vaddr(esp_addr+4)) sys_exit(-1);
			if(!is_user_vaddr(esp_addr+8)) sys_exit(-1);
			if((const char*)*(uint32_t*)(esp_addr+4) == NULL) sys_exit(-1);
			f->eax = filesys_create((const char*)*(uint32_t*)(esp_addr+4),(unsigned)*(uint32_t*)(esp_addr+8));
			break;

		case SYS_REMOVE:
			if(!is_user_vaddr(esp_addr+4)) sys_exit(-1);
			f->eax = filesys_remove((const char*)*(uint32_t*)(esp_addr+4));
			break;

		case SYS_OPEN:
			if(!is_user_vaddr(esp_addr+4) || (const char*)*(uint32_t*)(esp_addr+4) == NULL) sys_exit(-1);
			f->eax = sys_open((const char*)*(uint32_t*)(f->esp+4));
			
			break;

		case SYS_CLOSE:
			if(!is_user_vaddr(esp_addr+4) || thread_current()->fd[(int)*(uint32_t*)(esp_addr+4)] == NULL) sys_exit(-1);
			sys_close(esp_addr, (int)*(uint32_t*)(esp_addr+4));
			
			break;

		case SYS_FILESIZE:
			if(!is_user_vaddr(esp_addr+4) || thread_current()->fd[(int)*(uint32_t*)(esp_addr+4)]==NULL) sys_exit(-1);
			f->eax =  file_length(thread_current()->fd[(int)*(uint32_t*)(esp_addr+4)]);
			break;

		case SYS_SEEK:
			if(!is_user_vaddr(esp_addr+4) || !is_user_vaddr(esp_addr+8) || thread_current()->fd[(int)*(uint32_t*)(esp_addr+4)] == NULL) sys_exit(-1);
			file_seek(thread_current()->fd[(int)*(uint32_t*)(esp_addr+4)], (unsigned)*(uint32_t*)(esp_addr+8));
			break;

		case SYS_TELL:
			if(!is_user_vaddr(esp_addr+4) || thread_current()->fd[(int)*(uint32_t*)(esp_addr+4)] == NULL) sys_exit(-1);
			f->eax = file_tell(thread_current()->fd[(int)*(uint32_t*)(esp_addr+4)]);
			break;
   } 
	return;
}

int sys_fibonacci (int n){
	int a=1;
	int b=1;
	int add;
	if(n<=2) return 1;
	else{
		for(int i=2; i<n; i++){
			add = a+b;
			a=b;
			b=add;
		}
		return add;
	}
}

int sys_max_of_four_int(int a, int b, int c, int d){
	int max;
	if(a>=b)
		max=a;
	else max=b;
	if(max<c)
		max=c;
	if(max<d)
		max=d;
	return max;
}

void sys_exit (int status){
	printf("%s: exit(%d)\n", thread_name(), status);
	thread_current()->exit_stat = status;

	int i = 3;
	for(i = 3; i < FILE_D_SIZE; i++){
		if(thread_current()->fd[i] != NULL) {
			file_close(thread_current()->fd[i]);
			thread_current()->fd[i] = NULL;
		}
	}

	struct list_elem *e = list_begin(&(thread_current())->child_list);
	struct thread *t = list_entry(e, struct thread, child_element);


	for(; e != list_end(&(thread_current()->child_list)); e = list_next(e)){
		process_wait(t->tid);
		t = list_entry(e, struct thread, child_element);
	}

	file_close(thread_current()->cur_file);
	thread_exit();
}

//Proj 2

int sys_open(const char* filename){
	lock_acquire(&file_lock);
	struct file*f_in = filesys_open(filename);
	if(f_in==NULL){
		lock_release(&file_lock);
		return -1;
	}
	int i;
	for(i = 3; i<FILE_D_SIZE; i++){
		if(thread_current()->fd[i]==NULL){
				thread_current()->fd[i]=f_in;
				break;
		}
	}
	if(i >= FILE_D_SIZE){
		i = -1;
	}
	lock_release(&file_lock);
	return i;
	
}

int sys_read(void* esp_addr, int fd, void* buffer, int length){
	lock_acquire(&file_lock);
	int i;
	if (fd <= -1){
		lock_release(&file_lock);
		return -1;
	}
	else if(fd==0){
		for(i=0; i<(int)length; i++){
			if(input_getc() == '\0')break;

		}
		lock_release(&file_lock);
		return i;
	}
	else{
		if(thread_current()->fd[fd]==NULL){
			lock_release(&file_lock);
			sys_exit(-1);
		}
		i = file_read(thread_current()->fd[fd], buffer, length);
		lock_release(&file_lock);
		return i;
	}
	
}


int sys_write (int fd, const void *buffer, int length){
	lock_acquire(&file_lock);
	int i = -1;
	if(fd==1){
		putbuf((char*)buffer, (size_t)length);
		lock_release(&file_lock);
		return length;
	}
	else if(fd>=3){
		if(thread_current()->fd[fd]==NULL){
			lock_release(&file_lock);
			sys_exit(-1);
		}
		int i;
		i = file_write(thread_current()->fd[fd], buffer, length);
		lock_release(&file_lock);
		return i;
	}
	
	lock_release(&file_lock);
	return i;
	
}

int sys_close(void* esp_addr, int fd){
	file_close(thread_current()->fd[(int)*(uint32_t*)(esp_addr+4)]);
	thread_current()->fd[(int)*(uint32_t*)(esp_addr+4)] = NULL;
}